package com.rio.project12.model.network.weather

data class Weather(
    val count: Int,
    val data: List<Data>
)