package com.rio.project12.model.network.weather

data class WeatherX(
    val code: Int,
    val description: String,
    val icon: String
)